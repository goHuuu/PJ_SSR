import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile-editor',
  templateUrl: './profile-editor.component.html',
  styleUrls: ['./profile-editor.component.css']
})
export class ProfileEditorComponent implements OnInit {
 loginForm: FormGroup;


  constructor(private fb: FormBuilder, private router: Router) { }

  ngOnInit(): void {
    this.loginForm = this.fb.group({  // Crée une instance de FormGroup
      username: [],                   // Crée une instance de FormControl
      password: [],                   // Crée une instance de FormControl
    });
    
  }
  
  login() {
    console.log('Données du formulaire...', this.loginForm.value);
  }

  

}
