import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Le Confiblog';
}

export class imageFond {
  cheminImage:any = "C:\Users\rober\.vscode\Confiture\angular-tour-of-heroes\src\assets\fond-bois-vue-dessus_23-2148234292.jpg";
}

