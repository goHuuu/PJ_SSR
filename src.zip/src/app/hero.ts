export interface Confiture {
    id: number;
    name: string;
    recette: string;
    ingredients: string
  }